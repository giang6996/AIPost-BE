import { Response } from 'express'

type ErrorPayload = {
  code: string
  details?: unknown
}

export function sendSuccess(
  res: Response,
  data: unknown = {},
  message = 'Operation successful',
  statusCode = 200
) {
  return res.status(statusCode).json({
    success: true,
    data,
    message,
  })
}

export function sendError(
  res: Response,
  message = 'Operation failed',
  error: ErrorPayload = { code: 'INTERNAL_ERROR' },
  statusCode = 500
) {
  return res.status(statusCode).json({
    success: false,
    error,
    message,
  })
}