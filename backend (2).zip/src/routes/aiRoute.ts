import { Router } from 'express'
import { authMiddleware } from '../middleware/authMiddleware'
import {
  getOpenAiConfigHandler,
  saveOpenAiConfigHandler,
  deleteOpenAiConfigHandler,
  generateImageHandler,
  generatePostHandler,
  generateTitleHandler, 
  generateSeoHandler,
  rewriteSectionHandler
} from '../controllers/aiController'

const router = Router()

router.use(authMiddleware)

router.get('/config/openai', getOpenAiConfigHandler)
router.post('/config/openai', saveOpenAiConfigHandler)
router.put('/config/openai', saveOpenAiConfigHandler)
router.delete('/config/openai', deleteOpenAiConfigHandler)

router.post('/generate-image', generateImageHandler)
router.post('/generate-post', generatePostHandler)
router.post('/generate-title', generateTitleHandler)
router.post('/generate-seo', generateSeoHandler)
router.post('/rewrite-section', rewriteSectionHandler)

export default router