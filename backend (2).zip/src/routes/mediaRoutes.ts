import { Router } from 'express'
import {
  listDraftImagesHandler,
  uploadDraftImageHandler,
  uploadDraftImageToWpHandler,
  setDraftFeaturedImageHandler,
  insertDraftImageHandler
} from '../controllers/mediaController'
import { upload } from '../middleware/upload'

const router = Router()

router.get('/drafts/:id/images', listDraftImagesHandler)
router.post('/drafts/:id/images/upload', upload.single('image'), uploadDraftImageHandler)
router.post('/drafts/:id/images/:imageId/upload-to-wp', uploadDraftImageToWpHandler)
router.post('/drafts/:id/images/:imageId/set-featured', setDraftFeaturedImageHandler)
router.post('/drafts/:id/images/:imageId/insert', insertDraftImageHandler)

export default router