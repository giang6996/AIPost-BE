import express from 'express';
import siteRoutes from './routes/siteRoute'
import draftRoutes from './routes/draftRoute'
import mediaRoutes from './routes/mediaRoutes'
import aiRoutes from './routes/aiRoute'
import authRoute from './routes/authRoute'

const app = express()

app.use(express.json())

app.get('/health', (_req, res) => {
  res.json({
    success: true,
    message: 'Server is running',
  })
})

app.use('/auth', authRoute)
app.use('/ai', aiRoutes)
app.use('/sites', siteRoutes)
app.use('/drafts', draftRoutes)
app.use('/', mediaRoutes)

export default app