import { Request, Response } from 'express'
import {
  getCurrentUserFromToken,
  loginUser,
  logoutUser,
  registerUser,
  changePassword,
  updateProfile,
} from '../services/authService'
import { sendError, sendSuccess } from '../utils/apiResponse'

function getBearerToken(req: Request) {
  const authHeader = req.headers.authorization

  if (!authHeader) {
    return null
  }

  const [scheme, token] = authHeader.split(' ')

  if (scheme !== 'Bearer' || !token) {
    return null
  }

  return token.trim()
}

export async function registerHandler(req: Request, res: Response) {
  try {
    const email =
      typeof req.body.email === 'string' ? req.body.email.trim() : ''
    const name =
      typeof req.body.name === 'string' ? req.body.name.trim() : ''
    const password =
      typeof req.body.password === 'string' ? req.body.password : ''

    if (!email || !name || !password) {
      return sendError(
        res,
        'Email, name, and password are required',
        {
          code: 'VALIDATION_ERROR',
          details: 'email, name, and password are required',
        },
        400
      )
    }

    const user = await registerUser({
      email,
      name,
      password,
    })

    return sendSuccess(res, user, 'Registration successful')
  } catch (error) {
    const message =
      error instanceof Error &&
      (
        error.message === 'Email is required' ||
        error.message === 'Name is required' ||
        error.message === 'Password is required' ||
        error.message === 'Password must be at least 8 characters' ||
        error.message === 'Email already in use' ||
        error.message === 'Editor role not found'
      )
        ? error.message
        : 'Failed to register user'

    const code =
      error instanceof Error && error.message === 'Email already in use'
        ? 'EMAIL_ALREADY_EXISTS'
        : error instanceof Error &&
          (
            error.message === 'Email is required' ||
            error.message === 'Name is required' ||
            error.message === 'Password is required' ||
            error.message === 'Password must be at least 8 characters'
          )
        ? 'VALIDATION_ERROR'
        : error instanceof Error && error.message === 'Editor role not found'
        ? 'ROLE_NOT_FOUND'
        : 'REGISTER_FAILED'

    const statusCode =
      error instanceof Error && error.message === 'Email already in use'
        ? 409
        : error instanceof Error &&
          (
            error.message === 'Email is required' ||
            error.message === 'Name is required' ||
            error.message === 'Password is required' ||
            error.message === 'Password must be at least 8 characters' ||
            error.message === 'Editor role not found'
          )
        ? 400
        : 500

    return sendError(
      res,
      message,
      {
        code,
        details: error instanceof Error ? error.message : error,
      },
      statusCode
    )
  }
}

export async function loginHandler(req: Request, res: Response) {
  try {
    const email =
      typeof req.body.email === 'string' ? req.body.email.trim() : ''
    const password =
      typeof req.body.password === 'string' ? req.body.password : ''

    if (!email || !password) {
      return sendError(
        res,
        'Email and password are required',
        {
          code: 'VALIDATION_ERROR',
          details: 'email and password are required',
        },
        400
      )
    }

    const result = await loginUser({
      email,
      password,
    })

    return sendSuccess(res, result, 'Login successful')
  } catch (error) {
    const message =
      error instanceof Error &&
      (
        error.message === 'Email is required' ||
        error.message === 'Password is required' ||
        error.message === 'Invalid email or password' ||
        error.message === 'User account is not active'
      )
        ? error.message
        : 'Failed to login'

    const code =
      error instanceof Error &&
      (
        error.message === 'Email is required' ||
        error.message === 'Password is required'
      )
        ? 'VALIDATION_ERROR'
        : error instanceof Error && error.message === 'User account is not active'
        ? 'USER_INACTIVE'
        : 'LOGIN_FAILED'

    const statusCode =
      error instanceof Error &&
      (
        error.message === 'Email is required' ||
        error.message === 'Password is required'
      )
        ? 400
        : error instanceof Error &&
          (
            error.message === 'Invalid email or password' ||
            error.message === 'User account is not active'
          )
        ? 401
        : 500

    return sendError(
      res,
      message,
      {
        code,
        details: error instanceof Error ? error.message : error,
      },
      statusCode
    )
  }
}

export async function meHandler(req: Request, res: Response) {
  try {
      return sendSuccess(res, req.authUser, 'Current user fetched successfully')
      
  } catch (error) {
    return sendError(
      res,
      'Unauthorized',
      {
        code: 'UNAUTHORIZED',
        details: error instanceof Error ? error.message : error,
      },
      401
    )
  }
}

export async function updateProfileHandler(req: Request, res: Response) {
  try {
    const userId = req.authUser!.id

    const name =
      typeof req.body.name === 'string' ? req.body.name.trim() : undefined

    const email =
      typeof req.body.email === 'string' ? req.body.email.trim() : undefined

    if (
      (name === undefined || name.length === 0) &&
      (email === undefined || email.length === 0)
    ) {
      return sendError(
        res,
        'At least one field is required',
        {
          code: 'VALIDATION_ERROR',
          details: 'Provide at least one of: name, email',
        },
        400
      )
    }

    const result = await updateProfile({
      userId,
      name,
      email,
    })

    return sendSuccess(res, result, 'Profile updated successfully')
  } catch (error) {
    const message =
      error instanceof Error &&
      (
        error.message === 'User not found' ||
        error.message === 'At least one field is required' ||
        error.message === 'Email already in use'
      )
        ? error.message
        : 'Failed to update profile'

    const code =
      error instanceof Error && error.message === 'User not found'
        ? 'USER_NOT_FOUND'
        : error instanceof Error && error.message === 'Email already in use'
        ? 'EMAIL_ALREADY_EXISTS'
        : error instanceof Error && error.message === 'At least one field is required'
        ? 'VALIDATION_ERROR'
        : 'UPDATE_PROFILE_FAILED'

    const statusCode =
      error instanceof Error && error.message === 'User not found'
        ? 404
        : error instanceof Error &&
          (
            error.message === 'At least one field is required' ||
            error.message === 'Email already in use'
          )
        ? 400
        : 500

    return sendError(
      res,
      message,
      {
        code,
        details: error instanceof Error ? error.message : error,
      },
      statusCode
    )
  }
}

export async function changePasswordHandler(req: Request, res: Response) {
  try {
    const userId = req.authUser!.id

    const currentPassword =
      typeof req.body.currentPassword === 'string'
        ? req.body.currentPassword
        : ''

    const newPassword =
      typeof req.body.newPassword === 'string'
        ? req.body.newPassword
        : ''

    if (!currentPassword || !newPassword) {
      return sendError(
        res,
        'Current password and new password are required',
        {
          code: 'VALIDATION_ERROR',
          details: 'currentPassword and newPassword are required',
        },
        400
      )
    }

    const result = await changePassword({
      userId,
      currentPassword,
      newPassword,
    })

    return sendSuccess(res, result, 'Password changed successfully')
  } catch (error) {
    const message =
      error instanceof Error &&
      (
        error.message === 'User not found' ||
        error.message === 'User credential not found' ||
        error.message === 'Current password is required' ||
        error.message === 'New password is required' ||
        error.message === 'New password must be at least 8 characters' ||
        error.message === 'Current password is incorrect'
      )
        ? error.message
        : 'Failed to change password'

    const code =
      error instanceof Error && error.message === 'User not found'
        ? 'USER_NOT_FOUND'
        : error instanceof Error && error.message === 'User credential not found'
        ? 'USER_CREDENTIAL_NOT_FOUND'
        : error instanceof Error &&
          (
            error.message === 'Current password is required' ||
            error.message === 'New password is required' ||
            error.message === 'New password must be at least 8 characters'
          )
        ? 'VALIDATION_ERROR'
        : error instanceof Error && error.message === 'Current password is incorrect'
        ? 'INVALID_CURRENT_PASSWORD'
        : 'CHANGE_PASSWORD_FAILED'

    const statusCode =
      error instanceof Error && error.message === 'User not found'
        ? 404
        : error instanceof Error &&
          (
            error.message === 'User credential not found' ||
            error.message === 'Current password is required' ||
            error.message === 'New password is required' ||
            error.message === 'New password must be at least 8 characters' ||
            error.message === 'Current password is incorrect'
          )
        ? 400
        : 500

    return sendError(
      res,
      message,
      {
        code,
        details: error instanceof Error ? error.message : error,
      },
      statusCode
    )
  }
}

export async function logoutHandler(req: Request, res: Response) {
  try {
    const token = getBearerToken(req)

    if (!token) {
      return sendError(
        res,
        'Authorization token is required',
        { code: 'UNAUTHORIZED', details: 'Missing bearer token' },
        401
      )
    }

    const result = await logoutUser(token)

    return sendSuccess(res, result, 'Logout successful')
  } catch (error) {
    const isNotFound =
      error instanceof Error && error.message === 'Session not found'

    return sendError(
      res,
      isNotFound ? 'Session not found' : 'Failed to logout',
      {
        code: isNotFound ? 'SESSION_NOT_FOUND' : 'LOGOUT_FAILED',
        details: error instanceof Error ? error.message : error,
      },
      isNotFound ? 404 : 500
    )
  }
}