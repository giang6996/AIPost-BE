import { ImageSourceType, ImageInsertType } from '@prisma/client'
import { Request, Response } from 'express'
import path from 'path'
import { prisma } from '../lib/prisma'
import { createDraftImage, getDraftImages, uploadDraftImageToWp, setDraftFeaturedImage, insertDraftImage } from '../services/mediaService'
import { sendError, sendSuccess } from '../utils/apiResponse'
import { getParamAsString } from '../utils/paramString'
import { parsePositiveInt} from '../utils/positiveInt'

export async function listDraftImagesHandler(req: Request, res: Response) {
  try {
    const idParam = getParamAsString(req.params.id)
    const draftId = idParam ? parsePositiveInt(idParam) : null

    if (!draftId) {
      return sendError(
        res,
        'Invalid draft id',
        { code: 'INVALID_DRAFT_ID' },
        400
      )
    }

    const userId = req.authUser!.id



    const images = await getDraftImages(draftId, userId)

    return sendSuccess(res, images, 'Draft images fetched successfully')
  } catch (error) {
    const message =
      error instanceof Error && error.message === 'Draft not found'
        ? 'Draft not found'
        : 'Failed to fetch draft images'

    const code =
      error instanceof Error && error.message === 'Draft not found'
        ? 'DRAFT_NOT_FOUND'
        : 'FETCH_DRAFT_IMAGES_FAILED'

    const statusCode =
      error instanceof Error && error.message === 'Draft not found' ? 404 : 500

    return sendError(
      res,
      message,
      {
        code,
        details: error instanceof Error ? error.message : error,
      },
      statusCode
    )
  }
}

export async function uploadDraftImageHandler(req: Request, res: Response) {
  try {
    const idParam = getParamAsString(req.params.id)
    const draftId = idParam ? parsePositiveInt(idParam) : null
    
    if (!draftId) {
      return sendError(
        res,
        'Invalid draft id',
        { code: 'INVALID_DRAFT_ID' },
        400
      )
    }

    const userId = req.authUser!.id



    if (!req.file) {
      return sendError(
        res,
        'No image file uploaded',
        { code: 'FILE_REQUIRED' },
        400
      )
    }

    const { altText, caption, positionMarker } = req.body

    const image = await createDraftImage({
      draftId,
      userId: userId,
      sourceType: ImageSourceType.UPLOADED,
      localPath: path.normalize(req.file.path),
      altText,
      caption,
      positionMarker,
    })

    return sendSuccess(res, image, 'Draft image uploaded successfully', 201)
  } catch (error) {
    const message =
      error instanceof Error && error.message === 'Draft not found'
        ? 'Draft not found'
        : 'Failed to upload draft image'

    const code =
      error instanceof Error && error.message === 'Draft not found'
        ? 'DRAFT_NOT_FOUND'
        : 'UPLOAD_DRAFT_IMAGE_FAILED'

    const statusCode =
      error instanceof Error && error.message === 'Draft not found' ? 404 : 500

    return sendError(
      res,
      message,
      {
        code,
        details: error instanceof Error ? error.message : error,
      },
      statusCode
    )
  }
}


export async function uploadDraftImageToWpHandler(req: Request, res: Response) {
  try {
    const draftIdParam = getParamAsString(req.params.id)
    const imageIdParam = getParamAsString(req.params.imageId)

    const draftId = draftIdParam ? parsePositiveInt(draftIdParam) : null
    const imageId = imageIdParam ? parsePositiveInt(imageIdParam) : null

    if (!draftId) {
      return sendError(
        res,
        'Invalid draft id',
        { code: 'INVALID_DRAFT_ID' },
        400
      )
    }

    if (!imageId) {
      return sendError(
        res,
        'Invalid image id',
        { code: 'INVALID_IMAGE_ID' },
        400
      )
    }

    const userId = req.authUser!.id



    const { siteId } = req.body

    const result = await uploadDraftImageToWp({
      draftId,
      imageId,
      userId: userId,
      siteId,
    })

    return sendSuccess(res, result, 'Draft image uploaded to WordPress successfully')
  } catch (error) {
    const details = error instanceof Error ? error.message : error

    return sendError(
      res,
      'Failed to upload draft image to WordPress',
      {
        code: 'UPLOAD_DRAFT_IMAGE_TO_WP_FAILED',
        details,
      },
      500
    )
  }
}

export async function setDraftFeaturedImageHandler(req: Request, res: Response) {
  try {
    const draftIdParam = getParamAsString(req.params.id)
    const imageIdParam = getParamAsString(req.params.imageId)

    const draftId = draftIdParam ? parsePositiveInt(draftIdParam) : null
    const imageId = imageIdParam ? parsePositiveInt(imageIdParam) : null

    if (!draftId) {
      return sendError(res, 'Invalid draft id', { code: 'INVALID_DRAFT_ID' }, 400)
    }

    if (!imageId) {
      return sendError(res, 'Invalid image id', { code: 'INVALID_IMAGE_ID' }, 400)
    }

    const userId = req.authUser!.id

    if (!userId) {
      return sendError(res, 'Invalid user!', { code: 'USER_NOT_FOUND' }, 400)
    }

    const result = await setDraftFeaturedImage(draftId, imageId, userId)

    return sendSuccess(res, result, 'Featured image set successfully')
  } catch (error) {
    const details = error instanceof Error ? error.message : error
    return sendError(
      res,
      'Failed to set featured image',
      { code: 'SET_FEATURED_IMAGE_FAILED', details },
      500
    )
  }
}

export async function insertDraftImageHandler(req: Request, res: Response) {
  try {
    const draftIdParam = getParamAsString(req.params.id)
    const imageIdParam = getParamAsString(req.params.imageId)

    const draftId = draftIdParam ? parsePositiveInt(draftIdParam) : null
    const imageId = imageIdParam ? parsePositiveInt(imageIdParam) : null

    if (!draftId) {
      return sendError(res, 'Invalid draft id', { code: 'INVALID_DRAFT_ID' }, 400)
    }

    if (!imageId) {
      return sendError(res, 'Invalid image id', { code: 'INVALID_IMAGE_ID' }, 400)
    }

    const userId = req.authUser!.id

    if (!userId) {
      return sendError(res, 'Invalid user!', { code: 'USER_NOT_FOUND' }, 400)
    }

    const {
      insertType,
      targetHeadingText,
      targetHeadingLevel,
      paragraphIndexInSection,
    } = req.body

    if (!insertType) {
      return sendError(
        res,
        'insertType is required',
        { code: 'VALIDATION_ERROR' },
        400
      )
    }

    const result = await insertDraftImage({
      draftId,
      imageId,
      userId: userId,
      insertType: insertType as ImageInsertType,
      targetHeadingText,
      targetHeadingLevel,
      paragraphIndexInSection,
    })

    return sendSuccess(res, result, 'Draft image inserted successfully')
  } catch (error) {
    return sendError(
      res,
      'Failed to insert draft image',
      {
        code: 'INSERT_DRAFT_IMAGE_FAILED',
        details: error instanceof Error ? error.message : error,
      },
      500
    )
  }
}