import fs from 'fs'
import path from 'path'

const appDataRoot = path.resolve(process.cwd(), 'app_data')
const imageRoot = path.join(appDataRoot, 'images')
const uploadedImageRoot = path.join(imageRoot, 'uploaded')

export function ensureStorageDirectories() {
  const dirs = [appDataRoot, imageRoot, uploadedImageRoot]

  for (const dir of dirs) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true })
    }
  }
}

export const storagePaths = {
  appDataRoot,
  imageRoot,
  uploadedImageRoot,
}