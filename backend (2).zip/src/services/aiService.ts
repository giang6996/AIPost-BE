import OpenAI from 'openai'
import { prisma } from '../lib/prisma'
import { decrypt } from '../utils/crypto'
import { encrypt } from '../utils/crypto'
import {
  findSectionByHeading,
  replaceParagraphInSection,
  replaceSectionContent,
} from '../utils/htmlSection'


type SaveOpenAiConfigInput = {
  apiKey?: string
  defaultTextModel?: string
  defaultImageModel?: string
  isActive?: boolean
}

type GenerateImageInput = {
  userId: number
  prompt: string
  draftId?: number
  size?: '1024x1024' | '1536x1024' | '1024x1536' | 'auto'
  background?: 'opaque' | 'transparent' | 'auto'
}

type GenerateTitleInput = {
  userId: number
  prompt: string
  draftId?: number
  contentHtml?: string
  count?: number
  tone?: string
  maxTitleLength?: number
}

type GeneratePostInput = {
  userId: number
  prompt: string
  draftId?: number
  tone?: string
  structure?: string
  maxEstimatedWords?: number
}

type GenerateSeoInput = {
  userId: number
  prompt: string
  draftId?: number
  title?: string
  contentHtml?: string
  tone?: string
  maxMetaDescriptionLength?: number
}

type RewriteSectionInput = {
  userId: number
  draftId: number
  instruction: string
  targetHeadingText: string
  targetHeadingLevel?: number
  paragraphIndexInSection?: number
}

function toSafeAiConfig(config: {
  provider: string
  defaultTextModel: string | null
  defaultImageModel: string | null
  isActive: boolean
}) {
  return {
    provider: config.provider,
    defaultTextModel: config.defaultTextModel,
    defaultImageModel: config.defaultImageModel,
    isActive: config.isActive,
    hasApiKey: true,
  }
}

function estimateWordCountFromHtml(html: string) {
  const text = html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()

  if (!text) {
    return 0
  }

  return text.split(' ').length
}

function stripHtml(html: string) {
  return html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()
}

export async function getOpenAiConfig(userId: number) {
  const config = await prisma.aiProviderConfig.findUnique({
    where: {
      userId_provider: {
        userId,
        provider: 'openai',
      },
    },
  })

  if (!config) {
    return {
      provider: 'openai',
      defaultTextModel: null,
      defaultImageModel: null,
      isActive: false,
      hasApiKey: false,
    }
  }

  return {
    provider: config.provider,
    defaultTextModel: config.defaultTextModel,
    defaultImageModel: config.defaultImageModel,
    isActive: config.isActive,
    hasApiKey: true,
  }
}

export async function saveOpenAiConfig(
  userId: number,
  input: SaveOpenAiConfigInput
) {
  const existing = await prisma.aiProviderConfig.findUnique({
    where: {
      userId_provider: {
        userId,
        provider: 'openai',
      },
    },
  })

  const normalizedApiKey =
    typeof input.apiKey === 'string' ? input.apiKey.trim() : undefined

  const normalizedDefaultTextModel =
    typeof input.defaultTextModel === 'string' &&
    input.defaultTextModel.trim().length > 0
      ? input.defaultTextModel.trim()
      : undefined

  const normalizedDefaultImageModel =
    typeof input.defaultImageModel === 'string' &&
    input.defaultImageModel.trim().length > 0
      ? input.defaultImageModel.trim()
      : undefined

  const normalizedIsActive =
    typeof input.isActive === 'boolean' ? input.isActive : undefined

  if (!existing && !normalizedApiKey) {
    throw new Error('API key is required')
  }

  if (normalizedApiKey !== undefined && normalizedApiKey.length === 0) {
    throw new Error('API key is required')
  }

  const saved = await prisma.aiProviderConfig.upsert({
    where: {
      userId_provider: {
        userId,
        provider: 'openai',
      },
    },
    update: {
      apiKeyEncrypted:
        normalizedApiKey !== undefined
          ? encrypt(normalizedApiKey)
          : existing!.apiKeyEncrypted,
      defaultTextModel:
        normalizedDefaultTextModel !== undefined
          ? normalizedDefaultTextModel
          : existing?.defaultTextModel ?? null,
      defaultImageModel:
        normalizedDefaultImageModel !== undefined
          ? normalizedDefaultImageModel
          : existing?.defaultImageModel ?? null,
      isActive:
        normalizedIsActive !== undefined
          ? normalizedIsActive
          : existing?.isActive ?? true,
    },
    create: {
      userId,
      provider: 'openai',
      apiKeyEncrypted: encrypt(normalizedApiKey!),
      defaultTextModel: normalizedDefaultTextModel ?? null,
      defaultImageModel: normalizedDefaultImageModel ?? null,
      isActive: normalizedIsActive ?? true,
    },
  })

  return {
    provider: saved.provider,
    defaultTextModel: saved.defaultTextModel,
    defaultImageModel: saved.defaultImageModel,
    isActive: saved.isActive,
    hasApiKey: true,
  }
}

export async function deleteOpenAiConfig(userId: number) {
  const existing = await prisma.aiProviderConfig.findUnique({
    where: {
      userId_provider: {
        userId,
        provider: 'openai',
      },
    },
  })

  if (!existing) {
    throw new Error('OpenAI config not found')
  }

  await prisma.aiProviderConfig.delete({
    where: {
      userId_provider: {
        userId,
        provider: 'openai',
      },
    },
  })

  return {
    provider: 'openai',
  }
}

async function getActiveOpenAiClient(userId: number) {
  const config = await prisma.aiProviderConfig.findUnique({
    where: {
      userId_provider: {
        userId,
        provider: 'openai',
      },
    },
  })

  if (!config || !config.isActive) {
    throw new Error('OpenAI config not found or inactive')
  }

  const apiKey = decrypt(config.apiKeyEncrypted)

  return {
    client: new OpenAI({ apiKey }),
    config,
  }
}

export async function generateImage(input: GenerateImageInput) {
  const normalizedPrompt = input.prompt.trim()

  if (!normalizedPrompt) {
    throw new Error('Prompt is required')
  }

  const { client, config } = await getActiveOpenAiClient(input.userId)

  const modelName = config.defaultImageModel || 'gpt-image-1.5'

  const result = await client.images.generate({
    model: modelName,
    prompt: normalizedPrompt,
    size: input.size ?? '1024x1024',
    background: input.background ?? 'opaque',
  })

  const imageData = result.data?.[0]

  if (!imageData) {
    throw new Error('No image returned from OpenAI')
  }

  const imageBase64 =
    'b64_json' in imageData && typeof imageData.b64_json === 'string'
      ? imageData.b64_json
      : null

  if (!imageBase64) {
    throw new Error('OpenAI image response did not include base64 image data')
  }

  const revisedPrompt =
    'revised_prompt' in imageData && typeof imageData.revised_prompt === 'string'
      ? imageData.revised_prompt
      : null

  await prisma.usageLog.create({
    data: {
      draftId: input.draftId ?? null,
      userId: input.userId,
      actionType: 'generate_image',
      modelName,
      inputTokens: 0,
      outputTokens: 0,
      imageCount: 1,
      estimatedCost: 0,
    },
  })

  return {
    imageBase64,
    mimeType: 'image/png',
    modelName,
    revisedPrompt,
  }
}

export async function generateTitles(input: GenerateTitleInput) {
  const normalizedPrompt = input.prompt.trim()

  if (!normalizedPrompt) {
    throw new Error('Prompt is required')
  }

  const { client, config } = await getActiveOpenAiClient(input.userId)

  const modelName = config.defaultTextModel || 'gpt-5.4'
  const count = input.count ?? 5
  const maxTitleLength = input.maxTitleLength ?? 70

  const contentText = input.contentHtml
    ? input.contentHtml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()
    : ''

  const instructionParts = [
    `Generate exactly ${count} strong blog post titles.`,
    `Each title must be under approximately ${maxTitleLength} characters.`,
    'Return only a JSON object with this exact shape: {"titles":["title 1","title 2"]}',
    'Do not include numbering, explanation, or markdown.',
  ]

  if (input.tone?.trim()) {
    instructionParts.push(`Use this tone: ${input.tone.trim()}.`)
  }

  instructionParts.push(`Prompt and title brief: ${normalizedPrompt}`)

  if (contentText) {
    instructionParts.push(`Article context: ${contentText}`)
  }

  const response = await client.responses.create({
    model: modelName,
    input: instructionParts.join('\n\n'),
  })

  const rawText = response.output_text?.trim()

  if (!rawText) {
    throw new Error('No title content returned from OpenAI')
  }

  let parsed: unknown
  try {
    parsed = JSON.parse(rawText)
  } catch {
    throw new Error('Failed to parse generated titles')
  }

  const titles =
    typeof parsed === 'object' &&
    parsed !== null &&
    'titles' in parsed &&
    Array.isArray((parsed as { titles?: unknown }).titles)
      ? (parsed as { titles: unknown[] }).titles
          .filter((item): item is string => typeof item === 'string')
          .map((title) => title.trim())
          .filter((title) => title.length > 0)
      : []

  if (!titles.length) {
    throw new Error('No valid titles returned from OpenAI')
  }

  await prisma.usageLog.create({
    data: {
      draftId: input.draftId ?? null,
      userId: input.userId,
      actionType: 'generate_title',
      modelName,
      inputTokens: response.usage?.input_tokens ?? 0,
      outputTokens: response.usage?.output_tokens ?? 0,
      imageCount: 0,
      estimatedCost: 0,
    },
  })

  return {
    titles,
    modelName,
    generatedCount: titles.length,
  }
}

export async function generatePost(input: GeneratePostInput) {
  const normalizedPrompt = input.prompt.trim()

  if (!normalizedPrompt) {
    throw new Error('Prompt is required')
  }

  const { client, config } = await getActiveOpenAiClient(input.userId)

  const modelName = config.defaultTextModel || 'gpt-5.4'
  const maxEstimatedWords = input.maxEstimatedWords ?? 1200

  const instructionParts = [
    'Write a complete blog article in clean HTML.',
    'Return only HTML content, with no markdown fences and no explanation outside the article.',
    'Use semantic headings such as <h2> and <h3> where appropriate, and standard paragraph tags.',
    `Keep the article under approximately ${maxEstimatedWords} words.`,
  ]

  if (input.tone?.trim()) {
    instructionParts.push(`Use this tone: ${input.tone.trim()}.`)
  }

  if (input.structure?.trim()) {
    instructionParts.push(`Follow this structure: ${input.structure.trim()}.`)
  }

  instructionParts.push(`Topic and writing brief: ${normalizedPrompt}`)

  const response = await client.responses.create({
    model: modelName,
    input: instructionParts.join('\n\n'),
  })

  const contentHtml = response.output_text?.trim()

  if (!contentHtml) {
    throw new Error('No post content returned from OpenAI')
  }

  const estimatedWords = estimateWordCountFromHtml(contentHtml)

  await prisma.usageLog.create({
    data: {
      draftId: input.draftId ?? null,
      userId: input.userId,
      actionType: 'generate_post',
      modelName,
      inputTokens: response.usage?.input_tokens ?? 0,
      outputTokens: response.usage?.output_tokens ?? 0,
      imageCount: 0,
      estimatedCost: 0,
    },
  })

  return {
    contentHtml,
    modelName,
    estimatedWords,
  }
}

export async function generateSeo(input: GenerateSeoInput) {
  const normalizedPrompt = input.prompt.trim()

  if (!normalizedPrompt) {
    throw new Error('Prompt is required')
  }

  const { client, config } = await getActiveOpenAiClient(input.userId)

  const modelName = config.defaultTextModel || 'gpt-5.4'
  const maxMetaDescriptionLength = input.maxMetaDescriptionLength ?? 160

  const contentText = input.contentHtml ? stripHtml(input.contentHtml) : ''

  const instructionParts = [
    'Generate SEO metadata for a blog post.',
    'Return only a JSON object with this exact shape:',
    '{"seoTitle":"...","metaDescription":"...","focusKeyword":"...","ogTitle":"...","ogDescription":"..."}',
    `Keep the metaDescription under approximately ${maxMetaDescriptionLength} characters.`,
    'Do not include markdown, numbering, or explanation.',
  ]

  if (input.tone?.trim()) {
    instructionParts.push(`Use this tone: ${input.tone.trim()}.`)
  }

  instructionParts.push(`SEO brief: ${normalizedPrompt}`)

  if (input.title?.trim()) {
    instructionParts.push(`Post title: ${input.title.trim()}`)
  }

  if (contentText) {
    instructionParts.push(`Post content: ${contentText}`)
  }

  const response = await client.responses.create({
    model: modelName,
    input: instructionParts.join('\n\n'),
  })

  const rawText = response.output_text?.trim()

  if (!rawText) {
    throw new Error('No SEO content returned from OpenAI')
  }

  let parsed: unknown
  try {
    parsed = JSON.parse(rawText)
  } catch {
    throw new Error('Failed to parse generated SEO metadata')
  }

  const seo =
    typeof parsed === 'object' && parsed !== null
      ? {
          seoTitle:
            typeof (parsed as { seoTitle?: unknown }).seoTitle === 'string'
              ? (parsed as { seoTitle: string }).seoTitle.trim()
              : '',
          metaDescription:
            typeof (parsed as { metaDescription?: unknown }).metaDescription === 'string'
              ? (parsed as { metaDescription: string }).metaDescription.trim()
              : '',
          focusKeyword:
            typeof (parsed as { focusKeyword?: unknown }).focusKeyword === 'string'
              ? (parsed as { focusKeyword: string }).focusKeyword.trim()
              : '',
          ogTitle:
            typeof (parsed as { ogTitle?: unknown }).ogTitle === 'string'
              ? (parsed as { ogTitle: string }).ogTitle.trim()
              : '',
          ogDescription:
            typeof (parsed as { ogDescription?: unknown }).ogDescription === 'string'
              ? (parsed as { ogDescription: string }).ogDescription.trim()
              : '',
        }
      : null

  if (
    !seo ||
    !seo.seoTitle ||
    !seo.metaDescription ||
    !seo.focusKeyword ||
    !seo.ogTitle ||
    !seo.ogDescription
  ) {
    throw new Error('No valid SEO metadata returned from OpenAI')
  }

  await prisma.usageLog.create({
    data: {
      draftId: input.draftId ?? null,
      userId: input.userId,
      actionType: 'generate_seo',
      modelName,
      inputTokens: response.usage?.input_tokens ?? 0,
      outputTokens: response.usage?.output_tokens ?? 0,
      imageCount: 0,
      estimatedCost: 0,
    },
  })

  return seo
}

export async function rewriteSection(input: RewriteSectionInput) {
  const instruction = input.instruction.trim()
  const targetHeadingText = input.targetHeadingText.trim()

  if (!instruction) {
    throw new Error('Instruction is required')
  }

  if (!targetHeadingText) {
    throw new Error('Target heading text is required')
  }

  const draft = await prisma.draft.findFirst({
    where: {
      id: input.draftId,
      userId: input.userId,
    },
  })

  if (!draft) {
    throw new Error('Draft not found')
  }

  const section = findSectionByHeading({
    contentHtml: draft.contentHtml,
    targetHeadingText,
    targetHeadingLevel: input.targetHeadingLevel,
  })

  if (!section) {
    throw new Error('Section not found')
  }

  let targetHtml = ''
  let rewriteMode: 'section' | 'paragraph' = 'section'

  if (input.paragraphIndexInSection !== undefined) {
    const targetParagraph = section.paragraphHtmlList[input.paragraphIndexInSection - 1]

    if (!targetParagraph) {
      throw new Error('Paragraph not found')
    }

    targetHtml = targetParagraph
    rewriteMode = 'paragraph'
  } else {
    targetHtml = section.sectionInnerHtml
    rewriteMode = 'section'
  }

  const { client, config } = await getActiveOpenAiClient(input.userId)
  const modelName = config.defaultTextModel || 'gpt-5.4'

  const instructionParts = [
    rewriteMode === 'paragraph'
      ? 'Rewrite the following HTML paragraph.'
      : 'Rewrite the following HTML section content.',
    'Return only HTML.',
    'Do not include markdown fences.',
    rewriteMode === 'paragraph'
      ? 'Return exactly one rewritten paragraph in <p>...</p> format unless the instruction clearly requires a different inline structure.'
      : 'Preserve the section structure naturally using valid HTML paragraphs and subheadings when appropriate.',
    `Rewrite instruction: ${instruction}`,
    `Target heading: ${targetHeadingText}`,
    `Original HTML:\n${targetHtml}`,
  ]

  const response = await client.responses.create({
    model: modelName,
    input: instructionParts.join('\n\n'),
  })

  const rewrittenHtml = response.output_text?.trim()

  if (!rewrittenHtml) {
    throw new Error('No rewritten content returned from OpenAI')
  }

  let updatedContentHtml: string | null = null

  if (rewriteMode === 'paragraph') {
    updatedContentHtml = replaceParagraphInSection({
      contentHtml: draft.contentHtml,
      targetHeadingText,
      targetHeadingLevel: input.targetHeadingLevel,
      paragraphIndexInSection: input.paragraphIndexInSection!,
      newParagraphHtml: rewrittenHtml,
    })

    if (!updatedContentHtml) {
      throw new Error('Failed to replace paragraph in section')
    }
  } else {
    updatedContentHtml = replaceSectionContent({
      contentHtml: draft.contentHtml,
      targetHeadingText,
      targetHeadingLevel: input.targetHeadingLevel,
      newSectionInnerHtml: rewrittenHtml,
    })

    if (!updatedContentHtml) {
      throw new Error('Failed to replace section content')
    }
  }

  await prisma.draft.update({
    where: { id: draft.id },
    data: {
      contentHtml: updatedContentHtml,
      updatedAt: new Date(),
    },
  })

  await prisma.usageLog.create({
    data: {
      draftId: draft.id,
      userId: input.userId,
      actionType: rewriteMode === 'paragraph' ? 'rewrite_paragraph' : 'rewrite_section',
      modelName,
      inputTokens: response.usage?.input_tokens ?? 0,
      outputTokens: response.usage?.output_tokens ?? 0,
      imageCount: 0,
      estimatedCost: 0,
    },
  })

  return {
    draftId: draft.id,
    targetHeadingText,
    targetHeadingLevel: input.targetHeadingLevel ?? null,
    paragraphIndexInSection:
      input.paragraphIndexInSection !== undefined
        ? input.paragraphIndexInSection
        : null,
    rewrittenHtml,
    contentHtml: updatedContentHtml,
  }
}