import { ImageSourceType, ImageInsertType } from '@prisma/client'
import { buildImageHtmlBlock } from '../utils/imageBlock'
import { prisma } from '../lib/prisma'
import fs from 'fs'
import path from 'path'
import { decrypt } from '../utils/crypto'
import { uploadWpMedia } from './wordpressService'


export type CreateDraftImageInput = {
  draftId: number
  userId: number
  sourceType: ImageSourceType
  localPath?: string | null
  altText?: string | null
  caption?: string | null
  positionMarker?: string | null
}

type UploadDraftImageToWpInput = {
  draftId: number
  imageId: number
  userId: number
  siteId?: number
}

type InsertDraftImageInput = {
  draftId: number
  imageId: number
  userId: number
  insertType: ImageInsertType
  targetHeadingText?: string | null
  targetHeadingLevel?: number | null
  paragraphIndexInSection?: number | null
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

export async function getDraftImages(draftId: number, userId: number) {
  const draft = await prisma.draft.findFirst({
    where: {
      id: draftId,
      userId,
    },
  })

  if (!draft) {
    throw new Error('Draft not found')
  }

  return prisma.draftImage.findMany({
    where: { draftId },
    orderBy: { createdAt: 'desc' },
  })
}

export async function createDraftImage(input: CreateDraftImageInput) {
  const draft = await prisma.draft.findFirst({
    where: {
      id: input.draftId,
      userId: input.userId,
    },
  })

  if (!draft) {
    throw new Error('Draft not found')
  }

  return prisma.draftImage.create({
    data: {
      draftId: input.draftId,
      sourceType: input.sourceType,
      localPath: input.localPath ?? null,
      altText: input.altText?.trim() || null,
      caption: input.caption?.trim() || null,
      positionMarker: input.positionMarker?.trim() || null,
    },
  })
}

export async function uploadDraftImageToWp(input: UploadDraftImageToWpInput) {
  const draft = await prisma.draft.findFirst({
    where: {
      id: input.draftId,
      userId: input.userId,
    },
    include: {
      defaultSite: true,
    },
  })

  if (!draft) {
    throw new Error('Draft not found')
  }

  const image = await prisma.draftImage.findFirst({
    where: {
      id: input.imageId,
      draftId: input.draftId,
    },
  })

  if (!image) {
    throw new Error('Draft image not found')
  }

  if (!image.localPath) {
    throw new Error('Draft image local file path is missing')
  }

  const resolvedSiteId = input.siteId ?? draft.defaultSiteId

  if (!resolvedSiteId) {
    throw new Error('No target site selected')
  }

  const site = await prisma.wpSite.findFirst({
    where: {
      id: resolvedSiteId,
      userId: input.userId,
    },
  })

  if (!site) {
    throw new Error('Target site not found')
  }

  const absolutePath = path.resolve(image.localPath)

  if (!fs.existsSync(absolutePath)) {
    throw new Error('Local image file not found')
  }

  const fileBuffer = fs.readFileSync(absolutePath)
  const filename = path.basename(absolutePath)
  const ext = path.extname(filename).toLowerCase()

  let mimeType = 'application/octet-stream'
  if (ext === '.jpg' || ext === '.jpeg') mimeType = 'image/jpeg'
  if (ext === '.png') mimeType = 'image/png'
  if (ext === '.webp') mimeType = 'image/webp'
  if (ext === '.gif') mimeType = 'image/gif'

  const uploadResult = await uploadWpMedia({
    siteUrl: site.siteUrl,
    wpUsername: site.wpUsername,
    wpApplicationPassword: decrypt(site.wpApplicationPasswordEncrypted),
    fileBuffer,
    filename,
    mimeType,
    altText: image.altText,
    caption: image.caption,
  })

  if (!uploadResult.success) {
    throw new Error(uploadResult.message)
  }

  return prisma.draftImage.update({
    where: { id: image.id },
    data: {
      remoteUrl: uploadResult.sourceUrl ?? null,
      wpMediaId: uploadResult.wpMediaId ?? null,
    },
  })
}

function insertAtEndOfArticle(contentHtml: string, imageHtml: string) {
  return `${contentHtml}\n${imageHtml}`
}

function insertAfterHeading(
  contentHtml: string,
  headingText: string,
  headingLevel: number | null,
  imageHtml: string
) {
  const levelPattern = headingLevel ? `h${headingLevel}` : 'h[1-6]'
  const pattern = new RegExp(
    `(<${levelPattern}[^>]*>\\s*${escapeRegExp(headingText)}\\s*<\\/${levelPattern}>)`,
    'i'
  )

  if (!pattern.test(contentHtml)) {
    throw new Error('Target heading not found')
  }

  return contentHtml.replace(pattern, `$1\n${imageHtml}`)
}

export async function insertDraftImage(input: InsertDraftImageInput) {
  const draft = await prisma.draft.findFirst({
    where: {
      id: input.draftId,
      userId: input.userId,
    },
  })

  if (!draft) {
    throw new Error('Draft not found')
  }

  const image = await prisma.draftImage.findFirst({
    where: {
      id: input.imageId,
      draftId: input.draftId,
    },
  })

  if (!image) {
    throw new Error('Draft image not found')
  }

  if (!image.remoteUrl) {
    throw new Error('Draft image is not uploaded to WordPress yet')
  }

  const imageHtml = buildImageHtmlBlock({
    remoteUrl: image.remoteUrl,
    altText: image.altText,
    caption: image.caption,
  })

  let updatedHtml = draft.contentHtml

  switch (input.insertType) {
    case ImageInsertType.END_OF_ARTICLE:
      updatedHtml = insertAtEndOfArticle(draft.contentHtml, imageHtml)
      break

    case ImageInsertType.AFTER_HEADING:
      if (!input.targetHeadingText) {
        throw new Error('targetHeadingText is required for AFTER_HEADING')
      }

      updatedHtml = insertAfterHeading(
        draft.contentHtml,
        input.targetHeadingText,
        input.targetHeadingLevel ?? null,
        imageHtml
      )
      break

    default:
      throw new Error('Insert type not implemented yet')
  }

  await prisma.draft.update({
    where: { id: draft.id },
    data: {
      contentHtml: updatedHtml,
    },
  })

  const updatedImage = await prisma.draftImage.update({
    where: { id: image.id },
    data: {
      insertType: input.insertType,
      targetHeadingText: input.targetHeadingText ?? null,
      targetHeadingLevel: input.targetHeadingLevel ?? null,
      paragraphIndexInSection: input.paragraphIndexInSection ?? null,
      isInserted: true,
    },
  })

  return {
    image: updatedImage,
    contentHtml: updatedHtml,
  }
}

export async function setDraftFeaturedImage(
  draftId: number,
  imageId: number,
  userId: number
) {
  const draft = await prisma.draft.findFirst({
    where: {
      id: draftId,
      userId,
    },
  })

  if (!draft) {
    throw new Error('Draft not found')
  }

  const image = await prisma.draftImage.findFirst({
    where: {
      id: imageId,
      draftId,
    },
  })

  if (!image) {
    throw new Error('Draft image not found')
  }

  return prisma.draft.update({
    where: { id: draftId },
    data: {
      featuredImageId: image.id,
      featuredImageUrl: image.remoteUrl ?? image.localPath ?? null,
      featuredImageAlt: image.altText ?? null,
    },
    include: {
      featuredImage: true,
      images: true,
    },
  })
}